exports.config = module.exports.config = {
    "conf1": "val1"
};

exports.start = module.exports.start = function start(){
    console.log("log from my module start()");
};